# How To See Liked Reels & Liked Posts On Instagram? [in 2025]

In this article, we will guide you through the steps to see your liked reels and liked posts on Instagram in 2025.

You can also check out this video tutorial for a visual walkthrough: https://www.youtube.com/watch?v=1LkAJajT_lc.

## Where to Find Your Instagram Activity?

To start, you need to navigate to your **Instagram activity** section.

This is where all your interactions on Instagram, including your liked posts and reels, can be found.

Here’s how to do it:

1. **Open the Instagram App**: Make sure you're logged into your account.
  
2. **Go to Your Profile**: Tap on your profile icon located at the bottom right corner of the screen.

3. **Access Menu**: Look for the **hamburger menu** (three horizontal lines) in the upper right corner.

## What is the Hamburger Menu and How to Access It?

The hamburger menu is a commonly used icon in apps representing hidden navigation options.

On Instagram, it provides various functionalities, including access to settings and your activity.

To access the hamburger menu:

- Simply tap on the three horizontal lines in the top right corner of your profile page. 
- This will reveal a drop-down list of different options related to your account.

## How to Select Interactions on Instagram?

Once you've opened the hamburger menu, you can easily find your interactions.

Here’s how:

1. **Tap on 'Your Activity'**: From the dropdown menu, select **Your Activity**. 

2. **Navigate to Interactions**: Within this section, you'll find various options related to your account activity. 

3. **Select 'Interactions'**: Tap on **Interactions** to manage and view your liked posts and reels.

## What Types of Activity Can You Manage on Instagram?

Instagram offers users several types of interactions to manage:

- **Liked Posts**: A list of all posts you have liked.
  
- **Liked Reels**: A compilation of reels that you enjoyed.
  
- **Comments History**: Check the comments you've made on different posts.
  
- **Story Replies History**: Review the replies you’ve given to Instagram stories.
  
- **Reviews History**: See your past reviews on business accounts and products.

This feature allows you to easily navigate through your Instagram history and maintains transparency of your interactions.

## How to View and Delete Your Liked Posts and Reels?

Now that you are in the interactions section, viewing and managing your liked posts and reels is straightforward.

### To view:

1. **Scroll Through Your Liked Content**: In the interactions section, you will be presented with a list of all Instagram posts and reels you have liked. 

2. **Tap on Any Liked Item**: You can tap on any post or reel to view it directly.

### To delete:

If you wish to remove a ‘like’ from any post or reel:

1. **Find the Post or Reel**: Locate the item you wish to remove your like from.

2. **Tap the Heart Icon**: Click on the red heart icon underneath the post or reel. Once tapped, the heart icon will turn grey, indicating that you've unliked it.

3. **Confirm Your Action**: You can refresh the page to ensure that the item has been removed from your liked list.

By following these simple steps, managing your liked content on Instagram will become a breeze.

It’s essential to keep track of your activity, whether for decluttering your interest or simply revisiting past content that resonated with you.

## Conclusion

Navigating Instagram can be overwhelming, especially with the multitude of features it offers. 

By understanding **how to see liked reels and liked posts on Instagram**, you'll be able to manage your interactions effectively. 

Remember:

- Access your activity via the hamburger menu.
- Use the interactions section to find all your liked content.
- Easily delete any posts or reels from your liked list with just a few taps.

With 2025 bringing new updates and features to social media, staying informed about navigating your favorite platforms will enhance your overall experience. 

Happy Instagramming!